package com.capgemini.hms.service;

import java.util.List;

import com.capgemini.hms.DAO.HotelDaoImpl;
import com.capgemini.hms.DAO.IHotelDao;
import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.dto.Users;

public class HotelServiceImpl implements IHotelService
{

	IHotelDao hotelDao;
	
	
	public HotelServiceImpl() 
	{

		hotelDao=new HotelDaoImpl();
	}


	@Override
	public int addHotel(Hotel hotel) throws HotelException {
		return hotelDao.addHotel(hotel);
	}


	@Override
	public List<Hotel> showAllHotels() throws HotelException 
	{
		return hotelDao.showAllHotels();
	}


	@Override
	public void updateHotels(Hotel hotel) throws HotelException 
	{
		hotelDao.updateHotels(hotel);
		
	}


	@Override
	public List<Hotel> searchHotels(String city) throws HotelException 
	{
		return hotelDao.searchHotels(city);
	}


	@Override
	public void removeHotel(String hotelId) throws HotelException
	{
		hotelDao.removeHotel(hotelId);
	}


	@Override
	public List<RoomDetails> showAllRooms() throws HotelException
	{
		return hotelDao.showAllRooms();
	}


	@Override
	public int addRoomDetails(RoomDetails room) throws HotelException
	{
		return hotelDao.addRoomDetails(room);
	}


	@Override
	public void updateRoomDetails(RoomDetails room) throws HotelException
	{
		hotelDao.updateRoomDetails(room);
	}


	@Override
	public RoomDetails getRoomDetails(String roomId) throws HotelException
	{
		return hotelDao.getRoomDetails(roomId);
	}


	@Override
	public List<BookingDetails> showAllBookings() throws HotelException
	{
		return hotelDao.showAllBookings();
	}


	@Override
	public int addBookingDetails(BookingDetails book) throws HotelException
	{
		return hotelDao.addBookingDetails(book);
	}


	@Override
	public boolean isUserExist(String unm) throws HotelException
	{
		return hotelDao.isUserExist(unm);
	}


	@Override
	public int addUSer(Users user) throws HotelException 
	{
		return hotelDao.addUSer(user);
	}


	@Override
	public List<Users> showAll() throws HotelException 
	{
		return hotelDao.showAll();
	}


	@Override
	public Hotel getHotelDetails(String hotelId) throws HotelException 
	{

		return hotelDao.getHotelDetails(hotelId);
	}


	@Override
	public Users getUserDetails(String userId) throws HotelException {
		
		return hotelDao.getUserDetails(userId);
	}


	@Override
	public void updateUserDetails(Users user) throws HotelException 
	{
		
		hotelDao.updateUserDetails(user);
		
	}


	


}
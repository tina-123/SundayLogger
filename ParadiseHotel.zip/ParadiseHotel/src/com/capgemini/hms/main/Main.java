package com.capgemini.hms.main;



import java.sql.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.dto.Users;
import com.capgemini.hms.service.HotelServiceImpl;
import com.capgemini.hms.service.IHotelService;

public class Main 
{
	private IHotelService hotelService=new HotelServiceImpl();

	public static void main(String[] args) 
	{
		Main hsUI = new Main();
		
		while(true)
		{
		hsUI.showMenu();
		}
		
	}
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("1) Add Hotel");
		System.out.println("2) Update Hotel");
		System.out.println("3) View RoomDetails");
		System.out.println("4) View Hotel Details");
		System.out.println("5)	View Booking");
		System.out.println("6) Show All USers");
		System.out.println("7) Search Hotel By City");
		System.out.println("8) Remove Hotel By Id");
		System.out.println("9) Add Room Details");
		System.out.println("10) Add Booking");
		System.out.println("11) Add User");
		System.out.println("12) Get Room Details");
		System.out.println("13) Update Room Details");
		System.out.println("14) Update Hotel");
		System.out.println("15) Get Hotel by Id");
		System.out.println("16) Update User");
		System.out.println("17) Get User By Id");


		
		int choice = scanner.nextInt();
		switch (choice)
		{
		case 1: addHotel(); 
		break;
		/*case 2: updateHotel();
		break;*/
		case 3: ShowRoomDetails(); 
		break;
		case 4: ShowHotelDetails();
		break;
		case 5: showAllBookings();
		break;
		case 6: showAll();
		break;
		case 7: searchHotels();
		break;
		case 8: removeHotel();
		break;
		case 9: addRoomDetails();
		break;
		case 10: addBookingDetails();
		break;
		case 11: addUSer();
		break;
		case 12: getRoomDetails();
		break;
		case 13: updateRoomDetails();
		break;
		case 14: updateHotels();
		break;
		case 15: getHotelDetails();
		break;
		case 16: UpdateUser();
		break;
		case 17:getUserById();
			
	}

}
	
	
	
	
	private void getUserById()
	{
		Scanner scanner= new Scanner(System.in);
		//System.out.println("Provide Hotel City");
		
		System.out.println("User Id");
		String userId = scanner.next();
		
		Users user = hotelService.getUserDetails(userId);
		System.out.println(user);	
		
		
	}
	private void UpdateUser() 
	
	{
		
		Scanner scanner= new Scanner(System.in);
		//System.out.println("Provide Hotel City");
		
		
		
		System.out.println("User name");
		String userNmae = scanner.next();
		
		
		try 
		{
			Users user = hotelService.getUserDetails(userNmae);
			System.out.println(user);
			
			//System.out.println(room.getHotelId());
			System.out.println("Do you want to update mobile no?");
			char ans=scanner.next().toLowerCase().charAt(0);
			
			if(ans=='y')
			{
				System.out.println("Enter new role");
				String role=scanner.next();
				user.setRole(role);
			}
			
			//System.out.println(room.getRoomNo());
			System.out.println("Do you want to update phone?");
			ans=scanner.next().toLowerCase().charAt(0);
			if(ans=='y')
			{
				System.out.println("Enter new phone");
				String phone=scanner.next();
				user.setPhoneNo(phone);
			}
			
			
			hotelService.updateUserDetails(user);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		
		/*
		Scanner scanner= new Scanner(System.in);
		//System.out.println("Provide Hotel City");
		
		
		
		System.out.println("Room Id");
		String userId = scanner.next();
		
		
		try 
		{
			Users user= hotelService.getUserDetails(userId);
			
			
			//System.out.println(room.getHotelId());
			System.out.println("Do you want to update user id?");
			char ans=scanner.next().toLowerCase().charAt(0);
			
			if(ans=='y')
			{
				System.out.println("Enter new id");
				String hId=scanner.next();
				user.setUserId(userId);
			}
			
			//System.out.println(room.getRoomNo());
			System.out.println("Do you want to update username?");
			if(ans=='y')
			{
				System.out.println("Enter new username");
				String uname=scanner.next();
				user.setUsername(uname);
			}
			
			
			hotelService.updateUserDetails(user);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		*/
		
		
	}
	private void addHotel() 
	{
		Scanner scanner= new Scanner(System.in);
		System.out.println("Provide Hotel Details");
		
		
		System.out.println("City");
		String city = scanner.next();
		
		System.out.println("HotelName");
		String hotelName = scanner.next();
		
		System.out.println("Address");
		String address = scanner.next();
		
		System.out.println("Description");
		String description = scanner.next();
		
		System.out.println("AvgRatePerNight");
		Float avgRatePerNight = scanner.nextFloat();
		
		System.out.println("PhoneNo1");
		String phoneNo1 = scanner.next();
		
		System.out.println("PhoneNo2");
		String phoneNo2 = scanner.next();
		
		System.out.println("Rating");
		String rating = scanner.next();
		
		System.out.println("Email");
		String email = scanner.next();
		
		System.out.println("Fax");
		String fax = scanner.next();
		
		Hotel hotel = new Hotel();
		
		
		hotel.setCity(city);
		hotel.setHotelName(hotelName);
		hotel.setAddress(address);
		hotel.setDescription(description);
		hotel.setAvgRatePerNight(avgRatePerNight);
		hotel.setPhoneNo1(phoneNo1);
		hotel.setPhoneNo2(phoneNo2);
		hotel.setRating(rating);
		hotel.setEmail(email);
		hotel.setFax(fax);
		
		try 
		{
		int hotel1 = hotelService.addHotel(hotel);
			System.out.println("Hotal Details added succesufully with id" + hotel1);
		}
		catch(HotelException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	/*
	private void updateHotel()
	{
		
		Scanner scanner =new Scanner(System.in);
		System.out.println("updating HotelDetails Information");
		
		System.out.println("\n Hotel ID:");
		int id = scanner.nextInt();
		
		try
		{
			// attempt to get employee assuming id passed is valid
			Hotel employee = hotelService.get
			
			//since emp object is retrieved updated it and send to update 
			
			System.out.println("Name: " + employee.getId());
			
			System.out.println("Do you want to update Name (y/n)? ");
			
			char reply= scanner.next().toLowerCase().charAt(0);
			
	}*/
	
	private void ShowRoomDetails() 
	{
		try
		{
			List<RoomDetails> rooms = hotelService.showAllRooms();
			
			Iterator<RoomDetails> it= rooms.iterator();
			
			System.out.println("Hotel_ID \troom_id \troom_no \troom_type \tper_night_rate \tavailability \tphoto");
			
			while(it.hasNext())
			{
				RoomDetails room = it.next();
				
				System.out.println(room.getHotelId() + "\t" + room.getRoomId()+"\t" +room.getRoomNo()+ "\t" + room.getRoomType() + "\t" + room.getPerNightRate()+ "\t" + room.getAvailability() + "\t" + room.getPhoto());
				
			}
			
			
		}
		catch(HotelException e)
		{
			e.printStackTrace();
		}
		
	}
	
	private void ShowHotelDetails() 
	{
		try
		{
			List<Hotel> hotels = hotelService.showAllHotels();
			
			Iterator<Hotel> it= hotels.iterator();
			
			System.out.println("Hotel_ID \tCity \tHotel Name \tAddress \tDescription \tRate \tPhone No1\tPhone No2\tRating\tEmail\tFax");
			
			while(it.hasNext())
			{
				Hotel hotel = it.next();
				
				System.out.println(hotel.getHotelId() + "\t" + hotel.getCity()+"\t" +hotel.getHotelName()+ "\t" + hotel.getAddress() + "\t" + hotel.getDescription()+ "\t" + hotel.getAvgRatePerNight() + "\t" + hotel.getPhoneNo1()+ "\t" + hotel.getPhoneNo2()+ "\t" + hotel.getRating()+ "\t" + hotel.getEmail()+ "\t" + hotel.getFax());
				
			}
			
			
		}
		catch(HotelException e)
		{
			e.printStackTrace();
		}
		
	}
	
	private void showAllBookings() 
	{
		try
		{
			List<BookingDetails> bookings = hotelService.showAllBookings();
			
			Iterator<BookingDetails> it= bookings.iterator();
			
			System.out.println("Book_ID \tRoomId \tUserId \tBooked From \tbooked To \tAdults \tChildren\tAmount");
			
			while(it.hasNext())
			{
				BookingDetails booking = it.next();
				
				System.out.println(booking.getBookId() + "\t" + booking.getRoomId()+"\t" +booking.getUserId()+ "\t" + booking.getBookedFrom() + "\t" + booking.getBookedTo()+ "\t" + booking.getNoOfAdults() + "\t" + booking.getNoOfChildren()+ "\t" +booking.getAmount());
				
			
			
			}
			
			
		}
		catch(HotelException e)
		{
			e.printStackTrace();
		}
		
	}



private void showAll() 
{
	try
	{
		List<Users> users=hotelService.showAll();
		
		Iterator<Users> it= users.iterator();
		
		System.out.println("Book_ID \tRoomId \tUserId \tBooked From \tbooked To \tAdults \tChildren\tAmount");
		
		while(it.hasNext())
		{
			Users user = it.next();
			
			System.out.println(user.getUserId() + "\t" + user.getPassword()+"\t" +user.getRole()+ "\t" + user.getUsername() + "\t" + user.getMobileNo()+ "\t" + user.getPhoneNo() + "\t" + user.getAddress()+ "\t" +user.getEmail());
		
		}
		
		
	}
	catch(HotelException e)
	{
		e.printStackTrace();
	}
}

private void searchHotels() 
{
	Scanner scanner= new Scanner(System.in);
	System.out.println("Provide Hotel City");
	
	System.out.println("City");
	String city = scanner.next();
	
	List<Hotel> hotel = hotelService.searchHotels(city);
	System.out.println(hotel);	
	
	Iterator<Hotel> it= hotel.iterator();
	
	while(it.hasNext())
	{
		Hotel h = it.next();
		
		System.out.println(h);
	}
}

private void removeHotel() 
{
	Scanner scanner= new Scanner(System.in);
	System.out.println("Provide Hotel ID");
	
	System.out.println("ID");
	String id = scanner.next();
	
	hotelService.removeHotel(id);
	
}

private void addRoomDetails() 
{
	
	Scanner scanner= new Scanner(System.in);
	System.out.println("Provide Room Details");
	
	System.out.println("hotelId");
	String hotelId = scanner.next();
	/*
	System.out.println("Room Id");
	String roomId = scanner.next();*/
	
	System.out.println("Room No");
	String roomNo = scanner.next();
	
	System.out.println("Room Type");
	String roomType = scanner.next();
	
	System.out.println("Rate");
	Float rate = scanner.nextFloat();
	
	System.out.println("ava");
	String ava = scanner.next();
	
	System.out.println("Photo");
	String photo = scanner.next();
	
	
	RoomDetails room = new RoomDetails();
	
	
	room.setHotelId(hotelId);
	/*room.setRoomId(roomId);*/
	room.setRoomNo(roomNo);
	room.setRoomType(roomType);
	room.setPerNightRate(rate);
	room.setAvailability(ava);
	room.setPhoto(photo);
	
	try 
	{
	int room1 = hotelService.addRoomDetails(room);
		System.out.println("Room Details added succesufully with id" + room1);
	}
	catch(HotelException e)
	{
		e.printStackTrace();
	}
	catch (Exception e) 
	{
		e.printStackTrace();
	}
}

private void addBookingDetails() 
{
	Scanner scanner= new Scanner(System.in);
	System.out.println("Provide Booking Details");
	
	System.out.println("Room Id");
	String roomId = scanner.next();
	
	System.out.println("User Id");
	String userId = scanner.next();
	
	System.out.println("Booked from");
	String bookedFrom = scanner.next();
	
	Date date = Date.valueOf(bookedFrom);
	
	System.out.println("booked to");
	String bookedTo = scanner.next();
	
	Date date1 = Date.valueOf(bookedTo);
	
	System.out.println("adults");
	int adults = scanner.nextInt();
	
	System.out.println("Children");
	int children = scanner.nextInt();
	
	System.out.println("Amount");
	Float amount = scanner.nextFloat();
	
	
	BookingDetails book = new BookingDetails();
	
	
	book.setRoomId(roomId);
	book.setUserId(userId);
	book.setBookedFrom(date);
	book.setBookedTo(date1);
	book.setNoOfAdults(adults);
	book.setNoOfChildren(children);
	book.setAmount(amount);
	
	try 
	{
	int book1 = hotelService.addBookingDetails(book);
		System.out.println("Booking Details added succesufully with id" + book1);
	}
	catch(HotelException e)
	{
		e.printStackTrace();
	}
	catch (Exception e) 
	{
		e.printStackTrace();
	}
	
}

private void addUSer() 
{
	
	Scanner scanner= new Scanner(System.in);
	System.out.println("Provide User Details");
	
	System.out.println("User Name");
	String username = scanner.next();
	
	System.out.println("password");
	String password = scanner.next();
	
	
	
	System.out.println("role");
	String role = scanner.next();
	
	
	
	System.out.println("mobile");
	String mobileNo = scanner.next();
	
	
	
	System.out.println("phoneNo");
	String phoneNo = scanner.next();
	
	System.out.println("address");
	String address = scanner.next();
	
	System.out.println("email");
	String email = scanner.next();
	
	
	Users user = new Users();
	
	
	user.setUsername(username);
	user.setPassword(password);
	user.setRole(role);
	user.setMobileNo(mobileNo);
	user.setPhoneNo(phoneNo);
	user.setAddress(address);
	user.setEmail(email);
	
	try 
	{
	int user1 = hotelService.addUSer(user);
		System.out.println("user Details added succesufully with id" + user1);
	}
	catch(HotelException e)
	{
		e.printStackTrace();
	}
	catch (Exception e) 
	{
		e.printStackTrace();
	}
	
}

private void getRoomDetails() 
{
	Scanner scanner= new Scanner(System.in);
	//System.out.println("Provide Hotel City");
	
	System.out.println("Room Id");
	String roomId = scanner.next();
	
	RoomDetails room = hotelService.getRoomDetails(roomId);
	System.out.println(room);	
	
	/*Iterator<Hotel> it= hotel.iterator();
	
	while(it.hasNext())
	{
		Hotel h = it.next();
		
		System.out.println(h);
	}*/
	
}

private void updateRoomDetails() 
{
	Scanner scanner= new Scanner(System.in);
	//System.out.println("Provide Hotel City");
	
	
	
	System.out.println("Room Id");
	String roomId = scanner.next();
	
	
	try 
	{
		RoomDetails room = hotelService.getRoomDetails(roomId);
		
		
		//System.out.println(room.getHotelId());
		System.out.println("Do you want to update hotel id?");
		char ans=scanner.next().toLowerCase().charAt(0);
		
		if(ans=='y')
		{
			System.out.println("Enter new id");
			String hId=scanner.next();
			room.setHotelId(hId);
		}
		
		//System.out.println(room.getRoomNo());
		System.out.println("Do you want to update room no?");
		if(ans=='y')
		{
			System.out.println("Enter new id");
			String rNo=scanner.next();
			room.setHotelId(rNo);
		}
		
		
		hotelService.updateRoomDetails(room);
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	}
	
	
	
	
}

private void updateHotels() 
{
	Scanner scanner= new Scanner(System.in);
	//System.out.println("Provide Hotel City");
	
	
	
	System.out.println("Hotel Id");
	String hotelId = scanner.next();
	
	
	try 
	{
		Hotel hotel = hotelService.getHotelDetails(hotelId);
		
		
		//System.out.println(room.getHotelId());
		System.out.println("Do you want to update city?");
		char ans=scanner.next().toLowerCase().charAt(0);
		
		if(ans=='y')
		{
			System.out.println("Enter new city");
			String city=scanner.next();
			hotel.setCity(city);
		}
		
		//System.out.println(room.getRoomNo());
		System.out.println("Do you want to update hotel name?");
		if(ans=='y')
		{
			System.out.println("Enter new Hotel name");
			String name=scanner.next();
			hotel.setHotelName(name);
		}
		
		
		hotelService.updateHotels(hotel);
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	}
	
	
	

	
}

private void getHotelDetails() 
{
	Scanner scanner= new Scanner(System.in);
	//System.out.println("Provide Hotel City");
	
	System.out.println("Hotel Id");
	String hotelId = scanner.next();
	
	Hotel hotel = hotelService.getHotelDetails(hotelId);
	System.out.println(hotel);	
	
}
}



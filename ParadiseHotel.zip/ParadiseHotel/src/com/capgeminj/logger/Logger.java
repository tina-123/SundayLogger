package com.capgeminj.logger;

public class Logger 
{

}
